import axios from 'axios';

//Neveikia reikia info is butiko

// const baseURL = 'https://ost26.fastmag.fr';

// const authenticate = async (username, password) => {
//   const endpoint = '/boa/auth/token/index.ips';
//   try {
//     const response = await axios.post(`${baseURL}${endpoint}`, {
//       //   db: 'ULTIMA',
//       user: username,
//       pass: password,
//     });

//     if (response.data.status === 'OK') {
//       console.log(response.data.data.token);
//       return response.data.data.token;
//     } else {
//       console.log(response);

//       throw new Error('Authentication failed!');
//     }
//   } catch (error) {
//     console.error('Error during authentication:', error);
//   }
// };

// authenticate('APIWEB', 'symult@16');
